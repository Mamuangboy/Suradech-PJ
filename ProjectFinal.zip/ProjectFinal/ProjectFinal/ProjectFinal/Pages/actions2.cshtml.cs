using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectFinal.Pages
{
    public class actions2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
