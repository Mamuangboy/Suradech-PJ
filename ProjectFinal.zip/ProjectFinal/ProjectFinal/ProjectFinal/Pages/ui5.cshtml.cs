using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectFinal.Pages
{
    public class ui5Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
