using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectFinal.Pages
{
    public class ui3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
