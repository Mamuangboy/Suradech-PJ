using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectFinal.Pages
{
    public class uiModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
