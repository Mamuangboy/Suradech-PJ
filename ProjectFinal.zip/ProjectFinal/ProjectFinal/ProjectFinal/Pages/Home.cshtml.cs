using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectFinal.Pages
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
